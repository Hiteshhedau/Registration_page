package com.mednet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ename=request.getParameter("name");	
		String eemail=request.getParameter("email");	
		String epwd=request.getParameter("password");	
		String eaddress=request.getParameter("address");	
		String edob=request.getParameter("dob");	
		String egender=request.getParameter("gender");	
		
		Connection con=null;
		RequestDispatcher dispatcher=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/oakland","root","seaface");
			PreparedStatement pst=con.prepareStatement("insert into employee (ename,eemail,epwd,eaddress,edob,egender) values (?,?,?,?,?,?)");
		pst.setString(1, ename);
		pst.setString(2, eemail);
		pst.setString(3, epwd);
		pst.setString(4, eaddress);
		pst.setString(5, edob);
		pst.setString(6, egender);
		int rowCount=pst.executeUpdate();
		dispatcher=request.getRequestDispatcher("registration.jsp");
		if(rowCount>0) {
			request.setAttribute("status", "success");
		}else {
			request.setAttribute("status", "failed");
		}
		dispatcher.forward(request, response);
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
  	
  	
  	}

}
